﻿using GTA;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Ports;
using GTA.Native;
using GTA.UI;




namespace GTA_Teenenggr
{
    public class attacker: Script
    {
        static SerialPort serialPort;
        int arduinoSendValue = 2;
        public attacker()
        {
            this.Tick += onTick;
            Interval = 1;
            //this.KeyUp += onKeyUp;
            //this.KeyDown += onKeyDown;
            serialPort = new SerialPort();
            serialPort.PortName = "COM11";
            serialPort.BaudRate = 115200;
            serialPort.Open();
        }

        public void onTick(object sender, EventArgs e)
        {

            Ped playerPed = Game.Player.Character;
            if (playerPed.IsInVehicle())
            {
                Vehicle v = playerPed.CurrentVehicle;
                var maxSpeed = Function.Call<float>(Hash.GET_VEHICLE_ESTIMATED_MAX_SPEED, v);
                var val = (int)(maxSpeed);

                var currentSpeed = (int)v.Speed;
                var per = (int)((currentSpeed / maxSpeed) * 100);


                var txt = new TextElement(per.ToString(), new PointF(300f, 200f), scale: 1.3f);
                txt.Color = Color.Red;
                txt.Outline = true;
                txt.Draw();

                var txt2 = new TextElement(maxSpeed.ToString(), new PointF(300f, 300f), scale: 1.4f);
                txt2.Color = Color.Red;
                int newValue = 0;
                if (v.Acceleration == 1) {
                    newValue = 1;
                } else
                {
                    newValue = 2;
                }
                if (!playerPed.IsInVehicle())
                {
                    newValue = 2;
                }

                if (newValue != arduinoSendValue) {
                    arduinoSendValue = per;
                    //serialPort.WriteLine((per).ToString());
                    serialPort.WriteLine(newValue.ToString());
                }

            }
        }
    }
}
